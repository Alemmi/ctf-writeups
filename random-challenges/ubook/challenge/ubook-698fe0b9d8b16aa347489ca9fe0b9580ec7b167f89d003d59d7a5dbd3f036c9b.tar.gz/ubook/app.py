#!/usr/bin/env python3

import os
import re
import sys
import hashlib
import pymysql

from flask import Flask, abort, g, jsonify, request, render_template

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(16).hex()).encode()

FLASK_RUN_HOST = os.environ.get('FLASK_RUN_HOST', '0.0.0.0')
MYSQL_HOST = os.environ.get('MYSQL_HOST', 'localhost')
MYSQL_PORT = os.environ.get('MYSQL_PORT', 3306)
MYSQL_USER = os.environ.get('MYSQL_USER', 'root')
MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD', 'toor')
MYSQL_DATABASE = os.environ.get('MYSQL_DATABASE', 'ubook')
FLAG = os.environ.get('FLAG', 'ctf{fake_flag_sorry}')

QUERY_INS = 'INSERT INTO users (name, password, country, admin) VALUES (%s, %s, %s, FALSE)'
QUERY_GET = "SELECT * FROM users WHERE (BINARY CONCAT(name, ',', country) = %s)"


class User:
    """User class to handle user data."""
    def __init__(self, name: str, password: str, country: str):
        self.name = name
        self.password = password
        self.country = country

    def get(self, attr: str) -> str:
        return getattr(self, attr, None)

    def __repr__(self) -> str:
        return f'{self.name},{self.country}'
    
    def __str__(self) -> str:
        return f'{self.name},{self.country}'
    
    @staticmethod
    def to_user(s: str) -> 'User':
        # we don't want XSS, so we allow only safe symbols here
        return User(*s.split(',')) if re.match('^[\/\w:\.^\*@]{4,10},[\/\w:\.^\*@]{7,},[A-Z]{2}$', s) else s


def safe_unserialize(obj: any) -> any:
    """Unpickle the object safely. Thx copilot <3"""
    if isinstance(obj, dict):
        return {User.to_user(k): safe_unserialize(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [safe_unserialize(v) for v in obj]
    elif isinstance(obj, str):
        return User.to_user(obj)
    else:
        return obj


def get_db_conn():
    db_conf = {
                'user': MYSQL_USER,
                'password': MYSQL_PASSWORD,
                'host': MYSQL_HOST,
                'database': MYSQL_DATABASE}
    db_conn = getattr(g, 'db_conn', None)
    db_conf['cursorclass'] = pymysql.cursors.DictCursor
    if db_conn is None:
        try:
            g.db_conn = pymysql.connect(**db_conf)
            db_conn = g.db_conn
        except pymysql.Error as e:
            app.logger.critical(e)
            sys.exit(1)
    return db_conn


def query_handler(sql, cur, params=[]):
    try:
        cur.execute(sql, params)
    except Exception as e:
        cur.close()
        app.logger.critical(e)
        abort(500)
    
    return cur


def password_hash(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


@app.route('/api/register', methods=['POST'])
def register():
    try:
        users = safe_unserialize(request.json)
        db_conn = get_db_conn()
        with db_conn:
            with db_conn.cursor() as cur:
                for user in users:
                    phash = password_hash(user.get('password'))
                    cur = query_handler(QUERY_INS, cur, (user.get('name'), phash, user.get('country')))
            db_conn.commit()
        return jsonify({'err': False, 'msg': 'User(s) registered'})
    except Exception as e:
        return jsonify({'err': True, 'msg': 'Error registering user(s)'})


@app.route('/api/auth', methods=['POST'])
def auth():
    try:
        users = safe_unserialize(request.json)
        if len(users) != 1:
            return jsonify({'err': True, 'msg': 'Invalid user data'})
        user = users[0]
        db_conn = get_db_conn()
        with db_conn:
            with db_conn.cursor() as cur:
                cur = query_handler(QUERY_GET, cur, (user,))
                res = cur.fetchone()
                if res['password'] == password_hash(user.get('password')):
                    out = {'err': False,
                           'msg': FLAG if res.get('admin', False) else f'Welcome {user}'}
                    return jsonify(out)
        return jsonify({'err': True, 'msg': 'User not found'})
    except Exception as e:
        return jsonify({'err': True, 'msg': 'User not found'})
    


@app.route('/')
def index():
    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=False, host=FLASK_RUN_HOST, port=5000)
