DROP DATABASE IF EXISTS `ubook`;
CREATE DATABASE `ubook` DEFAULT CHARACTER SET utf8mb4;

USE `ubook`;

CREATE USER IF NOT EXISTS 'ubook'@'%' IDENTIFIED BY '56SkVeczB8mTXTFNyT45';

GRANT SELECT, INSERT ON `ubook`.* TO 'ubook'@'%';

FLUSH PRIVILEGES;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name`         VARCHAR(256) NOT NULL UNIQUE,
    `password`     VARCHAR(256) NOT NULL,
    `country`      VARCHAR(32) NOT NULL,
    `admin`        BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (`id`)
);

INSERT INTO `users` (`name`, `password`, `country`, `admin`) VALUES
    ('admin', 'bdf7401e3cd689dd722585d4ce45b052d85a77a1519b2512e4c3e7d95257e40d', 'AT', TRUE);